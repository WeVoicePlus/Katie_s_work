package com.example.translationapp;


import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {



    // Link to Layout
    private AutoCompleteTextView autoCompleteTextView;
    private ArrayAdapter<String> adapterLanguage;
    private Button translateBtn;
    private EditText input;
    private TextView result;


    // Variable
    private String selectedLanguage;
    private String[] language = {"English", "Japanese", "French"};
    private String[] languageCode = {"en", "ja", "fr"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        autoCompleteTextView = findViewById(R.id.auto_complete_txt);
        translateBtn = findViewById(R.id.btn);
        input = findViewById(R.id.input);
        result = findViewById(R.id.result);

        // adapter for dropdown list
        adapterLanguage = new ArrayAdapter<>(this, R.layout.list_item, language);
        autoCompleteTextView.setAdapter(adapterLanguage);

        // Dropdown list listener
        autoCompleteTextView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                selectedLanguage = item;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedLanguage = "English";
            }
        });

        //Translate Button Listener
        translateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // reset the result text
                result.setText("");

                // check if the input is empty or not
                if(input.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter your text to translate", Toast.LENGTH_SHORT).show();
                }
                else {
                    new Thread(networkTask).start();
                }
            }
        });


    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            Bundle data = msg.getData();
            String value = data.getString("output");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    result.setText(value);

                }
            });
        }
    };

    Runnable networkTask = new Runnable() {
        @Override
        public void run() {
            //Message
            Message msg = new Message();
            Bundle data = new Bundle();

            String text = input.getText().toString();
            int index = 0;
            for(int i =0; i<language.length;i++){
                if(selectedLanguage == language[i]){
                    index = i;
                }
            }
            //Create new Translator
                Translator translator = new Translator();
                String output = translator.TranslateText(text, languageCode[index]);

                data.putString("output",output);
                msg.setData(data);
                handler.handleMessage(msg);

        }
    };



}

